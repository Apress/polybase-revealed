﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using MongoDB.Bson.Serialization.Attributes;
using MongoDB.Bson.Serialization.IdGenerators;
using MongoDB.Bson;

namespace MongoPusher.Library.Models
{
	public class VolcanoModel
	{
		[BsonId(IdGenerator = typeof(CombGuidGenerator))]
		public Guid Id { get; set; }

		[BsonElement("VolcanoName")]
		public string VolcanoName { get; set; }

		[BsonElement("Country")]
		public string Country { get; set; }

		[BsonElement("Region")]
		public string Region { get; set; }

		[BsonElement("Location")]
		public Location Location { get; set; }

		[BsonElement("Elevation")]
		public int? Elevation { get; set; }

		[BsonElement("Type")]
		public string Type { get; set; }

		[BsonElement("Status")]
		public string Status { get; set; }

		[BsonElement("LastEruption")]
		public string LastEruption { get; set; }
	}

	public class Location
	{
		[BsonElement("Type")]
		public string Type { get; set; }

		[BsonElement("Coordinates")]
		public double[] Coordinates { get; set; }
	}
}
﻿using System;
using System.Collections.Generic;
using System.Linq;
using MongoPusher.Library.Models;
using MongoDB.Driver;
using MongoDB.Bson;
using System.Configuration;
using System.Security.Authentication;

namespace MongoPusher.Library
{
	public class Dal : IDisposable
	{
		private bool disposed = false;

		private string userName = ConfigurationManager.AppSettings["username"];
		private string host = ConfigurationManager.AppSettings["host"];
		private string password = ConfigurationManager.AppSettings["password"];

		// This sample uses a database named "PolyBaseTest" and a
		//collection named "Volcano".  The database and collection
		//will be automatically created if they don't already exist.
		private string volcano_dbName = ConfigurationManager.AppSettings["databaseName"];
		private string volcano_collectionName = ConfigurationManager.AppSettings["collectionName"];

		public Dal()
		{
		}

		public void CreateVolcano(VolcanoModel v)
		{
			var collection = GetVolcanoCollectionForEdit();
			try
			{
				collection.InsertOne(v);
			}
			catch (MongoCommandException ex)
			{
				string msg = ex.Message;
			}
		}

		private IMongoCollection<VolcanoModel> GetVolcanoCollectionForEdit()
		{
			MongoClientSettings settings = new MongoClientSettings();
			settings.Server = new MongoServerAddress(host, 10255);
			settings.UseSsl = true;
			settings.SslSettings = new SslSettings();
			settings.SslSettings.EnabledSslProtocols = SslProtocols.Tls12;

			MongoIdentity identity = new MongoInternalIdentity(volcano_dbName, userName);
			MongoIdentityEvidence evidence = new PasswordEvidence(password);

			settings.Credential = new MongoCredential("SCRAM-SHA-1", identity, evidence);

			MongoClient client = new MongoClient(settings);
			var database = client.GetDatabase(volcano_dbName);
			var todoTaskCollection = database.GetCollection<VolcanoModel>(volcano_collectionName);
			return todoTaskCollection;
		}

		#region IDisposable

		public void Dispose()
		{
			this.Dispose(true);
			GC.SuppressFinalize(this);
		}

		protected virtual void Dispose(bool disposing)
		{
			if (!this.disposed)
			{
				if (disposing)
				{
				}
			}

			this.disposed = true;
		}

		#endregion
	}
}

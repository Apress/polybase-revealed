﻿using System;
using System.Collections.Generic;
using System.IO;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using MongoPusher.Library.Models;
using MongoPusher.Library;
using Newtonsoft.Json;

namespace MongoPusher
{
	[TestClass]
	public class LoadVolcanoData
	{
		[TestMethod]
		public void CreateVolcano()
		{
			var volcano = new VolcanoModel
			{
				VolcanoName = "Rainier",
				Country = "United States",
				Region = "US-Washington",
				Location = new Location
				{
					Type = "Point",
					Coordinates = new double[] { -121.758, 46.87 }
				},
				Elevation = 4392,
				Type = "StratoVolcano",
				Status = "Dendrochronology",
				LastEruption = "Last known eruption from 1800-1899, inclusive"
			};

			Dal dal = new Dal();
			dal.CreateVolcano(volcano);
		}

		[TestMethod]
		public void LoadVolcanoes()
		{
			Dal dal = new Dal();
			
			var volcanodata = JsonConvert.DeserializeObject<IEnumerable<VolcanoModel>>(File.ReadAllText("VolcanoData.json"));

			foreach (var v in volcanodata)
			{
				dal.CreateVolcano(v);
			}
		}
	}
}
